package edu.ewubd.cse489;

import android.app.Activity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import edu.ewubd.cse489.R;

public class MainActivity extends Activity {
    private EditText nameTF, placeTF, dateTimeTF, capacityTF, budgetTF, emailTF, phoneTF, descriptionTF;
    private RadioButton indoorRB, outdoorRB, onlineRB;
    private String existingKey = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameTF = findViewById(R.id.etName);
        setEditTextMaxLength(nameTF, 20);
        placeTF = findViewById(R.id.etPlace);
        setEditTextMaxLength(placeTF, 70);

        //Util.getInstance().setkeyvalue(Context: ())

        indoorRB = findViewById(R.id.rbIndoor);
        outdoorRB =findViewById(R.id.rbOutdoor);
        onlineRB = findViewById(R.id.rbOnline);

        dateTimeTF = findViewById(R.id.etDateTime);
        setEditTextMaxLength(dateTimeTF, 70);

        capacityTF = findViewById(R.id.etCapacity);
        setEditTextMaxLength(capacityTF, 70);

        budgetTF = findViewById(R.id.etBudget);
        setEditTextMaxLength(budgetTF, 70);

        emailTF = findViewById(R.id.etEmail);
        setEditTextMaxLength(emailTF, 70);

        phoneTF = findViewById(R.id.etPhone);
        setEditTextMaxLength(phoneTF, 70);

        descriptionTF = findViewById(R.id.etDescription);
        setEditTextMaxLength(descriptionTF, 100);

        existingKey = getIntent().getStringExtra("EventKey");

        initializeFormwithExistingData(existingKey);

        findViewById(R.id.btnCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.finish();
            }
        });

        findViewById(R.id.btnShare).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("Share button was pressed ");
            }
        });

        findViewById(R.id.btnSave).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveEventData();
            }
        });

    }
    private void saveEventData() {
        String name = nameTF.getText().toString();
        String place = placeTF.getText().toString();
        String datetime = dateTimeTF.getText().toString();
        String capacity = capacityTF.getText().toString();
        String budget = budgetTF.getText().toString();
        String email = emailTF.getText().toString();
        String phone = phoneTF.getText().toString();
        String description = descriptionTF.getText().toString();

        String radioButtonValue = "";
        if(indoorRB.isChecked()) {
            radioButtonValue = "Indoor";
        } else if(outdoorRB.isChecked()) {
            radioButtonValue = "Outdoor";
        }else if(onlineRB.isChecked()) {
            radioButtonValue = "Online";
        }
        System.out.println("Name: "+ name);
        System.out.println("Place: "+ place);
        System.out.println("DateTime: "+ datetime);
        System.out.println("Capacity: "+ capacity);
        System.out.println("Budget: "+ budget);
        System.out.println("Email: "+ email);
        System.out.println("PhoneNo: "+ phone);
        System.out.println("Description: "+ description);

        String errorMsg = "";
        if(name == null || name.length() < 4) {
            errorMsg = "Event name is too short.";
        }
        if(place.isEmpty()) {
            errorMsg = "Event place can't be empty.";
        }
        if(radioButtonValue.isEmpty()) {
            errorMsg = "Please select a event type.";
        }
        if(errorMsg.isEmpty()) {
            //save the data in database
            String value = name+":-;-:"+place+":-;-:"+radioButtonValue+":-;-:"
                    +datetime+":-;-:"+capacity+":-;-:"
                    +budget+":-;-:"+email+":-;-:"
                    +phone+":-;-:"+description;

            String key = " ";
            if(existingKey != null){
                key = existingKey;
            }else{
                key = name+"_"+System.currentTimeMillis();
            }

            System.out.println("Key: "+key);
            System.out.println("Value: "+value);
            Util.getInstance().setKeyValue(MainActivity.this, key, value);

            //showSuccessDialouge("Event information has been saved successfully", "info");
            showDialog("Event information has been saved successfully","Info", "Ok",false );
        }
        else {
            //((TextView)findViewById(R.id.tvErrorMsg)).setText(errorMsg);
            //showErrorDialog(errorMsg, "Error in Event Data");
            showDialog(errorMsg, "Error in Event Data", "Back", true );
        }

    }

    private void initializeFormwithExistingData(String eventkey) {
        String value = Util.getInstance().getValueByKey(this, eventkey);
        System.out.println("Value: " + value);

        if(value != null) {

            String[] fieldValues = value.split(":-;-:");

            String name = fieldValues[0];
            String place = fieldValues[1];
            String radioButtonValue = fieldValues[2];
            String datetime = fieldValues[3];
            String capacity = fieldValues[4];
            String budget = fieldValues[5];
            String email = fieldValues[6];
            String phone = fieldValues[7];
            String description = fieldValues[8];

            nameTF.setText(name);
            placeTF.setText(place);
            dateTimeTF.setText(datetime);
            capacityTF.setText(capacity);
            budgetTF.setText(budget);
            emailTF.setText(email);
            phoneTF.setText(phone);
            descriptionTF.setText(description);
            if(radioButtonValue.equals("Indoor"))
            {
                indoorRB.setChecked(true);
            }
            else if(radioButtonValue.equals("Outdoor"))
            {
                indoorRB.setChecked(true);
            }
            else if(radioButtonValue.equals("Online"))
            {
                indoorRB.setChecked(true);
            }
        }
    }

    public void setEditTextMaxLength(EditText et, int length) {
        InputFilter[] filterArray = new InputFilter[1];
        filterArray[0] = new InputFilter.LengthFilter(length);
        et.setFilters(filterArray);
    }

    private void showDialog(String message, String title, String buttonLabel, boolean closeDialog){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        //Uncomment the below code to Set the message and title from the strings.xml file
        builder.setMessage(message);
        builder.setTitle(title);

        //Setting message manually and performing action on button click
        builder.setCancelable(false)
                .setNegativeButton(buttonLabel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        if(closeDialog){
                            dialog.cancel();
                        }else {
                            finish();
                        }
                    }
                });
        //Creating dialog box
        AlertDialog alert = builder.create();
        //Setting the title manually
        //alert.setTitle("Error Dialog");
        alert.show();

    }
}