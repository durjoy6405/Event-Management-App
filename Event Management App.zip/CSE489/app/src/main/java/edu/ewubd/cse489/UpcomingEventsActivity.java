package edu.ewubd.cse489;


import android.app.Activity;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class UpcomingEventsActivity extends Activity {
    private
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        findViewById(R.id.btnSave).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveEventData();




            }
        });
        findViewById(R.id.btnCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("Cancel Button was pressed"+ nameTF.getText().toString());
            }
        });
        findViewById(R.id.btnShare).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("Share Button was pressed"+ nameTF.getText().toString());
            }
        });


    }



    private void saveEventData(){
        String name = nameTF.getText().toString();
        String place = placeTF.getText().toString();
        String dTime = dateTimeTF.getText().toString();
        String cap = capacityTF.getText().toString();
        String budget = budgetTF.getText().toString();
        String email = emailTF.getText().toString();
        String phn = phoneTF.getText().toString();
        String desc = descriptionTF.getText().toString();

        String radioButtonValue= "";
        if(indoorRB.isChecked()){
            radioButtonValue="INDOOR";
        }
        else if(outdoorRB.isChecked()){
            radioButtonValue="OUTDOOR";
        }
        else if(onlineRB.isChecked()){
            radioButtonValue="ONLINE";
        }
        String errMsg="";
        if(name== null || name.length()<5){
            errMsg+="Event name should have at least five characters!";
        }
        if(place==null){
            errMsg+="Event name can not be empty";
        }
        if(email.contains("@")==false || email.contains(".com")==false){
            errMsg+="Invalid email";
        }
        if(phn.length()<11 || phn.length()>11){
            errMsg+="Invalid Phone Number";
        }
        if(radioButtonValue.isEmpty()){
            errMsg+="Please Select Event Type";
        }
        if(errMsg.isEmpty()){
            //save in the database
            String value = name+":-;-:"+place+":-;-:"+dTime+":-;-:"+cap+":-;-:"+
                    budget+":-;-:"+email+":-;-:"+phn+":-;-:"+desc+":-;-:"+radioButtonValue;
            String key = name;//+"_"+System.currentTimeMillis();
            System.out.println("Key :"+key);
            System.out.println("Value :"+value);
            Util.getInstance().setKeyValue(UpcomingEventsActivity.this,key,value);
        }
        else{
            ((TextView)findViewById(R.id.btnMsg)).setText(errMsg);
        }
        System.out.println("Name: "+ name);
        System.out.println("Place: "+ place);
        System.out.println("Date/Time: "+ dTime);
        System.out.println("Capacity: "+ cap);
        System.out.println("Budget: "+ budget);
        System.out.println("Email: "+ email);
        System.out.println("Phone no: "+ phn);
        System.out.println("Description: "+ desc);
    }

    private void initializeFormWithExistingData(String eventKey){
        String value = Util.getInstance().getValueByKey(this,eventKey);
        System.out.println("Values : "+value);
        if(value!=null){
            String [] fieldValues= value.split(":-;-:");
            String name = fieldValues[0];
            String place = fieldValues[1];
            String dTime = fieldValues[2];
            String cap = fieldValues[3];
            String budget = fieldValues[4];
            String email = fieldValues[5];
            String phn = fieldValues[6];
            String desc = fieldValues[7];
            String radioButtonValue =fieldValues[8];
            nameTF.setText(name);
            placeTF.setText(place);
            dateTimeTF.setText(dTime);
            capacityTF.setText(cap);
            budgetTF.setText(budget);
            emailTF.setText(email);
            phoneTF.setText(phn);
            descriptionTF.setText(desc);
            if (radioButtonValue.equals("INDOOR")){
                indoorRB.setChecked(true);
            }
            else if(radioButtonValue.equals("OUTDOOR")){
                outdoorRB.setChecked(true);
            }
            else if(radioButtonValue.equals("ONLINE")){
                onlineRB.setChecked(true);
            }
        }
    }


    public void setEditTextMaxLength(EditText et, int length) {
        InputFilter[] filterArray = new InputFilter[1];
        filterArray[0] = new InputFilter.LengthFilter(length);
        et.setFilters(filterArray);
    }
}