package edu.ewubd.cse489;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;

import androidx.appcompat.app.AlertDialog;

public class ProfileActivity extends Activity {
    private EditText nameTF, emailTF, phoneTF, useridTF, password1TF, password2TF;
    private String existingKey = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        nameTF = findViewById(R.id.etName);
        emailTF = findViewById(R.id.etEmail);
        phoneTF = findViewById(R.id.etPhone);
        useridTF = findViewById(R.id.etUserId);
        password1TF = findViewById(R.id.etPW1);
        password2TF = findViewById(R.id.etPw2);

        findViewById(R.id.btnCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ProfileActivity.this.finish();
            }
        });

        findViewById(R.id.btnSave).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                saveProfileData();
            }
        });

    }
    private void saveProfileData() {
        String name = nameTF.getText().toString();
        String email = emailTF.getText().toString();
        String phone = phoneTF.getText().toString();
        String userid = useridTF.getText().toString();
        String pw1 = password1TF.getText().toString();
        String pw2 = password2TF.getText().toString();

        String errorMsg = "";

        if(name == null || name.length() < 4) {
            errorMsg = "Name is too short & Must be at least 4 latter.";
        }
        if(email.isEmpty()) {
            errorMsg = "Email can't be empty.";
        }
        if(phone.isEmpty()) {
            errorMsg = "phone Number can't be empty.";
        }
        if(userid.isEmpty()) {
            errorMsg = "User ID can't be empty.";
        }

        if(errorMsg.isEmpty()) {
            //save the data in sharepref
            SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
            SharedPreferences.Editor perfsEditor = sharedPreferences.edit();
            perfsEditor.putString("user_name",name);
            perfsEditor.putString("user_email",email);
            perfsEditor.putString("User_phone",phone);
            perfsEditor.putString("user_id",userid);
            perfsEditor.putString("password", pw1);
            perfsEditor.commit();

            // Store Profile information in remote server

            showDialog("Profile information has been saved successfully","Info", "GO",false );
        }
        else {
            showDialog(errorMsg, "Error in Profile Data", "Back", true );
        }

    }

    public void setEditTextMaxLength(EditText et, int length) {
        InputFilter[] filterArray = new InputFilter[1];
        filterArray[0] = new InputFilter.LengthFilter(length);
        et.setFilters(filterArray);
    }

    private void showDialog(String message, String title, String buttonLabel, boolean closeDialog){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        //Uncomment the below code to Set the message and title from the strings.xml file
        builder.setMessage(message);
        builder.setTitle(title);

        //Setting message manually and performing action on button click
        builder.setCancelable(false)
                .setNegativeButton(buttonLabel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        if(closeDialog){
                            //dialog.cancel();
                        }else {
                            finish();
                        }
                    }
                });
        //Creating dialog box
        AlertDialog alert = builder.create();
        //Setting the title manually
        //alert.setTitle("Error Dialog");
        alert.show();

    }
}