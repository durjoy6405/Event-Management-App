package edu.ewubd.cse489;

public class Event {
    String key = "";
    String name = "";
    String place = "";
    String datetime = "";
    String capacity = "";
    String budget = "";
    String email = "";
    String phone = "";
    String description = "";
    String radioButtonValue = "";

    public Event(String key, String name, String place, String datetime, String capacity, String budget, String email, String phone, String description, String radioButtonValue) {
        this.key = key;
        this.name = name;
        this.place = place;
        this.datetime = datetime;
        this.capacity = capacity;
        this.budget = budget;
        this.email = email;
        this.phone = phone;
        this.description = description;
        this.radioButtonValue = radioButtonValue;
    }
}