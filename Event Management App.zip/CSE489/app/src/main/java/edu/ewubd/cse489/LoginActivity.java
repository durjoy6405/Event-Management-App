package edu.ewubd.cse489;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;

public class LoginActivity extends Activity {
    private EditText useridTF, passwordTF;
    SharedPreferences sharedPreferences;
    private SharedPreferences.Editor perfsEditor;
    private CheckBox rememberUserCheck, rememberLoginrCheck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        useridTF = findViewById(R.id.etUserId);
        setEditTextMaxLength(useridTF, 8);

        passwordTF = findViewById(R.id.etPassword);
        setEditTextMaxLength(passwordTF, 4);

        rememberUserCheck = findViewById(R.id.cbRemUser);
        rememberLoginrCheck = findViewById(R.id.cbRemLogin);

        sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        String remember_val = sharedPreferences.getString("remember", null);

        if(remember_val == null);
        else if(remember_val.equals("user")){
            rememberUserCheck.setChecked(true);
            useridTF.setText(sharedPreferences.getString("user_id", null));
        }
//        else if(remember_val.equals("login")){
//            Intent i = new Intent(LoginActivity.this, UpcomingEventActivity.class);
//            startActivity(i);
//            finish();
//        }
        findViewById(R.id.linkSignup).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LoginActivity.this, ProfileActivity.class);
                startActivity(i);
            }
        });

        findViewById(R.id.btnLogin).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                String userid = useridTF.getText().toString();
                String password = passwordTF.getText().toString();
                perfsEditor = sharedPreferences.edit();
                String errMsg = "";
                if (userid == null || userid.length()<4){
                    errMsg+= "User ID Must have at least 4 characters\n";
                }
                if (password == null || password.length() !=4 ){
                    errMsg+= "Password must have exactly 4 characters\n";
                }
                if (errMsg.isEmpty()){
                    String user = sharedPreferences.getString("user_id", null);
                    String pass = sharedPreferences.getString("password", null);

//                    if (user==null || pass == null){
//                        perfsEditor.putString("user_id",userid);
//                        perfsEditor.putString("password", password);
//                        if(rememberUserCheck.isChecked()){
//                            perfsEditor.putString("remember","user");
//                        } else if(rememberLoginrCheck.isChecked()) {
//                            perfsEditor.putString("remember", "login");
//                        }
//                        else {
//                            perfsEditor.putString("remember",null);
//                        }
//                        perfsEditor.apply();
//                        showAlertDialog("Sign up Successfull", "Sign-Up", "OK", false);
//                        finish();
//                    }
//                    else {
                        if (user.equals(userid) && pass.equals(password)){
                            Intent i = new Intent(LoginActivity.this, UpcomingEventActivity.class);
                            startActivity(i);
                            if(rememberUserCheck.isChecked()){
                                perfsEditor.putString("remember","user");
                            } else if(rememberLoginrCheck.isChecked()) {
                                perfsEditor.putString("remember", "login");
                            }
                            else {
                                perfsEditor.putString("remember",null);
                            }
                            perfsEditor.apply();
                            finish();
                        }
                        else{
                            showAlertDialog("Wrong User ID or Password", "Login Error", "Back", true);
                        }
//                    }
                }
                else {
                    showAlertDialog(errMsg, "Login Error", "Back", true);
                }
            }
        });
        findViewById(R.id.btnExit).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                LoginActivity.this.finish();
            }
        });
    }
    public void setEditTextMaxLength(EditText et, int length){
        InputFilter[] filterArray = new InputFilter[1];
        filterArray[0] = new InputFilter.LengthFilter(length);
        et.setFilters(filterArray);
    }
    private void showAlertDialog(String message, String title, String buttonLabel, boolean closeDialog){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
//Uncomment the below code to Set the message and title from the strings.xml file
        builder.setMessage(message) .setTitle(title);
//Setting message manually and performing action on button click
        builder.setCancelable(false)
                .setNegativeButton(buttonLabel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        if(closeDialog) {
                            dialog.cancel();
                        }
                        else {
                            Intent i = new Intent(LoginActivity.this, UpcomingEventActivity.class);
                            startActivity(i);
                        }
                    }
                });
//Creating dialog box
        AlertDialog alert = builder.create();
//Setting the title manually
// alert.setTitle("Error Dialog");
        alert.setTitle(title);
        alert.show();
    }
}